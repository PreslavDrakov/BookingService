﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace frontend.Business
{
    internal class PhoneNumberMustStartWithZeroException : Exception
    {
        public PhoneNumberMustStartWithZeroException() : base("Phone number must start with 0!")
        {

        }
    }
}

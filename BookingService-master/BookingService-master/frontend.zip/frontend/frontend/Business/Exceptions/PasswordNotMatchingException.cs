﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace frontend.Business
{
    internal class PasswordNotMatchingException : Exception
    {
        public PasswordNotMatchingException() : base("Wrong password!")
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace frontend.Business
{
    internal class UserNotFoundException : Exception
    {
        public UserNotFoundException() : base("No user with such username!")
        {

        }
    }
}

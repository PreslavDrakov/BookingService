﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace frontend.Business
{
    internal class PhoneMustHaveTenDigitsException : Exception
    {
        public PhoneMustHaveTenDigitsException() : base("Phone number must have exactly 10 digits!")
        {
        }
    }
}

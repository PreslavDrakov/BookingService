﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace frontend.Business
{
    internal class InvalidEmailException : Exception
    {
        public InvalidEmailException() : base("Invalid e-mail!")
        {

        }
    }
}
